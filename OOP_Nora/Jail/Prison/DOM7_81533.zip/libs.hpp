#include <iostream>
#include <cstring>
#include <cmath>
#include <ctime>
#include <assert.h>

using namespace std;
